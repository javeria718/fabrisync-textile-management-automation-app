import 'package:fabri_sync/Model/userModel.dart';
import 'package:fabri_sync/singleton/singleton.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class LoginController {
  final String expectedRole; // ✅ 'admin' or 'manager'
  LoginController({required this.expectedRole});

  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  bool isLoading = false;
  bool showPassword = false;

  final supabase = Supabase.instance.client;

  void showError(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: Colors.red),
    );
  }

  Future<void> login(
    BuildContext context,
    String email,
    String password,
  ) async {
    try {
      isLoading = true;

      final AuthResponse response = await supabase.auth.signInWithPassword(
        email: email,
        password: password,
      );

      final user = response.user;
      if (user == null) {
        showError(context, "User not found.");
        return;
      }

      // ✅ Fetch profile safely
      final profile = await supabase
          .from('profiles')
          .select()
          .eq('id', user.id)
          .maybeSingle();

      if (profile == null) {
        await supabase.auth.signOut();
        showError(
          context,
          "Profile not found. Please sign up again or contact admin.",
        );
        return;
      }

      final userModel = UserModel.fromJson(profile);
      final profileRole = (userModel.role).toLowerCase();

      // ✅ STRICT ROLE MATCH
      if (profileRole != expectedRole.toLowerCase()) {
        await supabase.auth.signOut();
        showError(
          context,
          "Access denied. You can only login as ${expectedRole.toUpperCase()} here.",
        );
        return;
      }

      UserSingleton().userModel = userModel;

      // ✅ role-based navigation
      if (profileRole == 'admin') {
        Navigator.pushReplacementNamed(context, '/admin_dashboard');
      } else {
        Navigator.pushReplacementNamed(context, '/manager_panel');
      }
    } on AuthException catch (e) {
      final msg = e.message.toLowerCase();
      if (msg.contains('invalid') || msg.contains('credentials')) {
        showError(context, "Invalid email or password.");
        return;
      }
      showError(context, e.message);
    } catch (e) {
      showError(context, "Login failed: ${e.toString()}");
    } finally {
      isLoading = false;
    }
  }

  void validateAndLogin(BuildContext context) {
    final email = emailController.text.trim();
    final password = passwordController.text.trim();

    final emailRegex = RegExp(
      r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$",
    );

    if (email.isEmpty || password.isEmpty) {
      showError(context, "Please fill all fields.");
      return;
    }

    if (!emailRegex.hasMatch(email)) {
      showError(context, "Please enter a valid email address.");
      return;
    }

    login(context, email, password);
  }
}
