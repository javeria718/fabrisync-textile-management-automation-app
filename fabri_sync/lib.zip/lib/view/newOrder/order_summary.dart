// import 'dart:ui';
// import 'package:fabri_sync/Model/orderModel.dart';
// import 'package:fabri_sync/utils/customcolors.dart';
// import 'package:fabri_sync/view/dashboards/admin.dart';
// import 'package:fabri_sync/widgets/custom_appBar.dart';
// import 'package:fabri_sync/widgets/primary_button.dart';
// import 'package:flutter/material.dart';
// import 'package:intl/intl.dart';
// import 'package:supabase_flutter/supabase_flutter.dart';

// class OrderSummaryScreen extends StatelessWidget {
//   final OrderModel order;
//   final supabase = Supabase.instance.client;

//   OrderSummaryScreen({super.key, required this.order});

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.transparent,
//       appBar: buildGradientAppBar("Order Summary"),
//       body: gradientOrderBackground(
//         child: SingleChildScrollView(
//           padding: const EdgeInsets.all(18),
//           child: Center(
//             child: ConstrainedBox(
//               constraints: const BoxConstraints(maxWidth: 420),
//               child: ClipRRect(
//                 borderRadius: BorderRadius.circular(24),
//                 child: BackdropFilter(
//                   filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
//                   child: Container(
//                     padding: const EdgeInsets.all(24),
//                     decoration: BoxDecoration(
//                       color: Colors.white.withOpacity(0.12),
//                       borderRadius: BorderRadius.circular(24),
//                       border: Border.all(color: Colors.white.withOpacity(0.25)),
//                       boxShadow: const [
//                         BoxShadow(
//                           color: Colors.black38,
//                           blurRadius: 30,
//                           offset: Offset(0, 20),
//                         ),
//                       ],
//                     ),
//                     child: Column(
//                       mainAxisSize: MainAxisSize.min,
//                       children: [
//                         /// 🧾 ORDER SUMMARY CARD
//                         Container(
//                           padding: const EdgeInsets.all(18),
//                           decoration: BoxDecoration(
//                             color: Colors.white.withOpacity(0.08),
//                             borderRadius: BorderRadius.circular(18),
//                             border: Border.all(
//                               color: Colors.white.withOpacity(0.15),
//                             ),
//                             boxShadow: const [
//                               BoxShadow(
//                                 color: Colors.black26,
//                                 blurRadius: 20,
//                                 offset: Offset(0, 10),
//                               ),
//                             ],
//                           ),
//                           child: Column(
//                             crossAxisAlignment: CrossAxisAlignment.start,
//                             children: [
//                               const SizedBox(height: 12),
//                               _row("Order ID", order.orderId),
//                               _row("Department", order.currentDepartment),
//                               _row("Quantity", order.quantity.toString()),

//                               _row(
//                                 "Date",
//                                 DateFormat(
//                                   "dd MMM yyyy",
//                                 ).format(order.createdAt),
//                               ),
//                               _row(
//                                 "Time",
//                                 DateFormat("hh:mm a").format(order.createdAt),
//                               ),

//                               _row("Status", order.status),
//                             ],
//                           ),
//                         ),

//                         const SizedBox(height: 18),

//                         /// ⏱ ESTIMATED TIME CARD
//                         _frostedGradientCard(
//                           title: "Estimated Time",
//                           value:
//                               "${order.estimatedTime.toStringAsFixed(2)} hrs",
//                           icon: Icons.access_time,
//                         ),

//                         const SizedBox(height: 14),

//                         /// 💰 ESTIMATED COST CARD
//                         _frostedGradientCard(
//                           title: "Estimated Cost",
//                           value:
//                               "PKR ${order.estimatedCost.toStringAsFixed(0)}",
//                           icon: Icons.currency_rupee,
//                         ),

//                         const SizedBox(height: 24),

//                         /// ✅ CREATE ORDER BUTTON
//                         SizedBox(
//                           width: double.infinity,
//                           child: primaryButton(
//                             context: context,
//                             text: "Create Order",
//                             onTap: () async {
//                               try {
//                                 final supabase = Supabase.instance.client;

//                                 // 1️⃣ Generate a unique order ID
//                                 final String newOrderId =
//                                     'ORD-${DateTime.now().millisecondsSinceEpoch}';

//                                 // 2️⃣ Insert ONLY into ordersmain
//                                 // ✅ department_orders ka kaam trigger karega (insert_first_department)
//                                 await supabase.from('ordersmain').insert({
//                                   'order_id': newOrderId,
//                                   'quantity': order.quantity,
//                                   'current_department':
//                                       'CUTTING', // keep uppercase
//                                   'status': 'pending',
//                                   'estimated_total_time': order.estimatedTime,
//                                   'estimated_total_cost': order.estimatedCost,
//                                   // optional: 'estimated_dept_hours': ... (if you store JSON)
//                                 });

//                                 // 3️⃣ Success UX
//                                 if (!context.mounted) return;

//                                 Navigator.pushAndRemoveUntil(
//                                   context,
//                                   MaterialPageRoute(
//                                     builder: (context) =>
//                                         const AdminDashboardScreen(),
//                                   ),
//                                   (route) => false,
//                                 );

//                                 ScaffoldMessenger.of(context).showSnackBar(
//                                   const SnackBar(
//                                     content: Text("Order created successfully"),
//                                     backgroundColor: Colors.green,
//                                   ),
//                                 );
//                               } catch (e) {
//                                 debugPrint("Order creation error: $e");
//                                 if (!context.mounted) return;

//                                 ScaffoldMessenger.of(context).showSnackBar(
//                                   const SnackBar(
//                                     content: Text("Failed to create order"),
//                                     backgroundColor: Colors.red,
//                                   ),
//                                 );
//                               }
//                             },
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   /// 🔹 Helper for rows
//   Widget _row(String label, String value) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 6),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           Text(label, style: TextStyle(color: Colors.white.withOpacity(0.7))),
//           Text(
//             value,
//             style: const TextStyle(
//               color: Colors.white,
//               fontWeight: FontWeight.w600,
//             ),
//           ),
//         ],
//       ),
//     );
//   }

//   /// 🔹 Frosted Gradient Card (same style as Estimate Time card)
//   Widget _frostedGradientCard({
//     required String title,
//     required String value,
//     required IconData icon,
//   }) {
//     return Container(
//       padding: const EdgeInsets.all(18),
//       decoration: BoxDecoration(
//         borderRadius: BorderRadius.circular(18),
//         gradient: const LinearGradient(
//           begin: Alignment.topLeft,
//           end: Alignment.bottomRight,
//           colors: [
//             Color(0x66FFFFFF), // semi-transparent white
//             Color(0x33E0EFFF), // soft bluish-white
//           ],
//         ),
//         border: Border.all(color: Colors.white.withOpacity(0.15)),
//         boxShadow: const [
//           BoxShadow(
//             color: Colors.black26,
//             blurRadius: 20,
//             offset: Offset(0, 10),
//           ),
//         ],
//       ),
//       child: Row(
//         children: [
//           CircleAvatar(
//             radius: 28,
//             backgroundColor: Colors.white.withOpacity(0.2),
//             child: Icon(icon, color: Colors.white, size: 28),
//           ),
//           const SizedBox(width: 16),
//           Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             mainAxisAlignment: MainAxisAlignment.center,
//             children: [
//               Text(
//                 title,
//                 style: const TextStyle(color: Colors.white70, fontSize: 14),
//               ),
//               Text(
//                 value,
//                 style: const TextStyle(
//                   color: Colors.white,
//                   fontSize: 18,
//                   fontWeight: FontWeight.bold,
//                 ),
//               ),
//             ],
//           ),
//         ],
//       ),
//     );
//   }
// }
import 'dart:ui';
import 'package:fabri_sync/Model/orderModel.dart';
import 'package:fabri_sync/utils/customcolors.dart';
import 'package:fabri_sync/view/dashboards/admin.dart';
import 'package:fabri_sync/widgets/custom_appBar.dart';
import 'package:fabri_sync/widgets/primary_button.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class OrderSummaryScreen extends StatelessWidget {
  final OrderModel order;
  final supabase = Supabase.instance.client;

  OrderSummaryScreen({super.key, required this.order});

  // Simple breakpoints (tweak if you want)
  static const double kTabletBp = 600;
  static const double kDesktopBp = 1024;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: buildGradientAppBar("Order Summary"),
      body: gradientOrderBackground(
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) {
              final w = constraints.maxWidth;

              final bool isDesktop = w >= kDesktopBp;
              final bool isTablet = w >= kTabletBp && w < kDesktopBp;

              // Responsive paddings
              final double horizontalPadding = isDesktop
                  ? 32
                  : isTablet
                  ? 24
                  : 16;

              final double verticalPadding = isDesktop
                  ? 28
                  : isTablet
                  ? 22
                  : 16;

              // Responsive card max width
              final double cardMaxWidth = isDesktop
                  ? 560
                  : isTablet
                  ? 480
                  : double.infinity;

              // Responsive typography
              final double titleFont = isDesktop ? 15 : 14;
              final double valueFont = isDesktop ? 19 : 18;
              final double rowFont = isDesktop ? 14 : 13;

              // Responsive icon sizes
              final double avatarRadius = isDesktop ? 30 : 28;
              final double iconSize = isDesktop ? 30 : 28;

              return SingleChildScrollView(
                padding: EdgeInsets.symmetric(
                  horizontal: horizontalPadding,
                  vertical: verticalPadding,
                ),
                child: Center(
                  child: ConstrainedBox(
                    constraints: BoxConstraints(maxWidth: cardMaxWidth),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(24),
                      child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
                        child: Container(
                          padding: EdgeInsets.all(isDesktop ? 28 : 24),
                          decoration: BoxDecoration(
                            color: Colors.white.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(24),
                            border: Border.all(
                              color: Colors.white.withOpacity(0.25),
                            ),
                            boxShadow: const [
                              BoxShadow(
                                color: Colors.black38,
                                blurRadius: 30,
                                offset: Offset(0, 20),
                              ),
                            ],
                          ),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              /// 🧾 ORDER SUMMARY CARD
                              Container(
                                padding: EdgeInsets.all(isDesktop ? 20 : 18),
                                decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.08),
                                  borderRadius: BorderRadius.circular(18),
                                  border: Border.all(
                                    color: Colors.white.withOpacity(0.15),
                                  ),
                                  boxShadow: const [
                                    BoxShadow(
                                      color: Colors.black26,
                                      blurRadius: 20,
                                      offset: Offset(0, 10),
                                    ),
                                  ],
                                ),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(height: isDesktop ? 14 : 12),
                                    _row(
                                      "Order ID",
                                      order.orderId,
                                      fontSize: rowFont,
                                    ),
                                    _row(
                                      "Department",
                                      order.currentDepartment,
                                      fontSize: rowFont,
                                    ),
                                    _row(
                                      "Quantity",
                                      order.quantity.toString(),
                                      fontSize: rowFont,
                                    ),
                                    _row(
                                      "Date",
                                      DateFormat(
                                        "dd MMM yyyy",
                                      ).format(order.createdAt),
                                      fontSize: rowFont,
                                    ),
                                    _row(
                                      "Time",
                                      DateFormat(
                                        "hh:mm a",
                                      ).format(order.createdAt),
                                      fontSize: rowFont,
                                    ),
                                    _row(
                                      "Status",
                                      order.status,
                                      fontSize: rowFont,
                                      // optional highlight
                                      valueStyle: TextStyle(
                                        color: Colors.white,
                                        fontWeight: FontWeight.w700,
                                      ),
                                    ),
                                  ],
                                ),
                              ),

                              const SizedBox(height: 18),

                              /// ⏱ ESTIMATED TIME CARD
                              _frostedGradientCard(
                                title: "Estimated Time",
                                value:
                                    "${order.estimatedTime.toStringAsFixed(2)} hrs",
                                icon: Icons.access_time,
                                titleFont: titleFont,
                                valueFont: valueFont,
                                avatarRadius: avatarRadius,
                                iconSize: iconSize,
                              ),

                              const SizedBox(height: 14),

                              /// 💰 ESTIMATED COST CARD
                              _frostedGradientCard(
                                title: "Estimated Cost",
                                value:
                                    "PKR ${order.estimatedCost.toStringAsFixed(0)}",
                                icon: Icons.currency_rupee,
                                titleFont: titleFont,
                                valueFont: valueFont,
                                avatarRadius: avatarRadius,
                                iconSize: iconSize,
                              ),

                              const SizedBox(height: 24),

                              /// ✅ CREATE ORDER BUTTON
                              SizedBox(
                                width: double.infinity,
                                child: primaryButton(
                                  context: context,
                                  text: "Create Order",
                                  onTap: () async {
                                    try {
                                      final supabase = Supabase.instance.client;

                                      final String newOrderId =
                                          'ORD-${DateTime.now().millisecondsSinceEpoch}';

                                      await supabase.from('ordersmain').insert({
                                        'order_id': newOrderId,
                                        'quantity': order.quantity,
                                        'current_department': 'CUTTING',
                                        'status': 'pending',
                                        'estimated_total_time':
                                            order.estimatedTime,
                                        'estimated_total_cost':
                                            order.estimatedCost,
                                      });

                                      if (!context.mounted) return;

                                      Navigator.pushAndRemoveUntil(
                                        context,
                                        MaterialPageRoute(
                                          builder: (context) =>
                                              const AdminDashboardScreen(),
                                        ),
                                        (route) => false,
                                      );

                                      ScaffoldMessenger.of(
                                        context,
                                      ).showSnackBar(
                                        const SnackBar(
                                          content: Text(
                                            "Order created successfully",
                                          ),
                                          backgroundColor: Colors.green,
                                        ),
                                      );
                                    } catch (e) {
                                      debugPrint("Order creation error: $e");
                                      if (!context.mounted) return;

                                      ScaffoldMessenger.of(
                                        context,
                                      ).showSnackBar(
                                        const SnackBar(
                                          content: Text(
                                            "Failed to create order",
                                          ),
                                          backgroundColor: Colors.red,
                                        ),
                                      );
                                    }
                                  },
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }

  /// ✅ Responsive row that won’t overflow on small screens
  Widget _row(
    String label,
    String value, {
    double fontSize = 13,
    TextStyle? valueStyle,
  }) {
    final labelStyle = TextStyle(
      color: Colors.white.withOpacity(0.7),
      fontSize: fontSize,
    );

    final defaultValueStyle = TextStyle(
      color: Colors.white,
      fontSize: fontSize,
      fontWeight: FontWeight.w600,
    );

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Label (left)
          Expanded(
            flex: 4,
            child: Text(label, style: labelStyle, softWrap: true),
          ),
          const SizedBox(width: 12),
          // Value (right) - wraps/ellipsis safely
          Expanded(
            flex: 5,
            child: Align(
              alignment: Alignment.centerRight,
              child: Text(
                value,
                style: valueStyle ?? defaultValueStyle,
                textAlign: TextAlign.right,
                softWrap: true,
                overflow: TextOverflow.visible,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _frostedGradientCard({
    required String title,
    required String value,
    required IconData icon,
    required double titleFont,
    required double valueFont,
    required double avatarRadius,
    required double iconSize,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(18),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0x66FFFFFF), Color(0x33E0EFFF)],
        ),
        border: Border.all(color: Colors.white.withOpacity(0.15)),
        boxShadow: const [
          BoxShadow(
            color: Colors.black26,
            blurRadius: 20,
            offset: Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: avatarRadius,
            backgroundColor: Colors.white.withOpacity(0.2),
            child: Icon(icon, color: Colors.white, size: iconSize),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(color: Colors.white70, fontSize: titleFont),
                ),
                const SizedBox(height: 4),
                Text(
                  value,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: valueFont,
                    fontWeight: FontWeight.bold,
                  ),
                  softWrap: true,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
