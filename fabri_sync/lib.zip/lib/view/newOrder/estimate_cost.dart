import 'dart:ui';
import 'package:fabri_sync/Model/orderModel.dart';
import 'package:fabri_sync/utils/customcolors.dart';
import 'package:fabri_sync/view/newOrder/order_summary.dart';
import 'package:fabri_sync/widgets/custom_appBar.dart';
import 'package:fabri_sync/widgets/primary_button.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class EstimateCostScreen extends StatefulWidget {
  final TextEditingController quantityCtrl;
  final TextEditingController materialCostCtrl;
  final double estimatedTime;

  const EstimateCostScreen({
    super.key,
    required this.quantityCtrl,
    required this.materialCostCtrl,
    required this.estimatedTime,
  });

  @override
  State<EstimateCostScreen> createState() => _EstimateCostScreenState();
}

class _EstimateCostScreenState extends State<EstimateCostScreen> {
  double estimatedCost = 0;
  double hourlyRate = 0;
  bool isLoadingRate = true;

  bool hasCalculated = false;
  bool isCardTapped = false;

  @override
  void initState() {
    super.initState();
    fetchHourlyRate();
  }

  Future<void> fetchHourlyRate() async {
    final supabase = Supabase.instance.client;

    final response = await supabase
        .from('master_cost_config')
        .select('value')
        .eq('cost_type', 'hourly_rate')
        .maybeSingle();

    if (response == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Hourly rate not found in database!"),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    setState(() {
      hourlyRate = (response['value'] as num).toDouble();
      isLoadingRate = false;
    });
  }

  void calculateCost() {
    if (isLoadingRate) return;

    final qty = double.tryParse(widget.quantityCtrl.text) ?? 0;
    final materialCost = double.tryParse(widget.materialCostCtrl.text) ?? 0;

    setState(() {
      estimatedCost =
          (widget.estimatedTime * hourlyRate) + (qty * materialCost);
      hasCalculated = true;
      isCardTapped = true;
    });
  }

  void handleNext() {
    if (!hasCalculated) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Please tap the card to calculate cost first."),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    final tempOrder = OrderModel(
      orderId: "ORD-${DateTime.now().millisecondsSinceEpoch}",
      quantity: int.parse(widget.quantityCtrl.text),
      currentDepartment: "Cutting",
      status: "Pending",
      createdAt: DateTime.now(),
      estimatedTime: widget.estimatedTime,
      estimatedCost: estimatedCost,
    );

    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => OrderSummaryScreen(order: tempOrder)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: buildGradientAppBar("New Order"),
      body: gradientOrderBackground(
        child: Center(
          child: SingleChildScrollView(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(24),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
                  child: Container(
                    constraints: const BoxConstraints(minHeight: 400),
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: Colors.white.withOpacity(0.25)),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black38,
                          blurRadius: 30,
                          offset: Offset(0, 20),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        /// ESTIMATE COST CARD
                        GestureDetector(
                          onTap: calculateCost,
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            curve: Curves.easeOut,
                            height: isCardTapped ? 120 : 140,
                            padding: const EdgeInsets.all(18),
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(18),
                              gradient: const LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [
                                  Color(0x66FFFFFF), // subtle white overlay
                                  Color(0x33E0EFFF), // soft bluish-white
                                ],
                              ),
                              border: Border.all(
                                color: Colors.white.withOpacity(0.15),
                              ),
                              boxShadow: const [
                                BoxShadow(
                                  color: Colors.black26,
                                  blurRadius: 20,
                                  offset: Offset(0, 10),
                                ),
                              ],
                            ),
                            child: Row(
                              children: [
                                CircleAvatar(
                                  radius: 28,
                                  backgroundColor: Colors.white.withOpacity(
                                    0.2,
                                  ),
                                  child: const Icon(
                                    Icons.analytics,
                                    color: Colors.white,
                                    size: 28,
                                  ),
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      const Text(
                                        "Estimated Cost",
                                        style: TextStyle(
                                          color: Colors.white70,
                                          fontSize: 14,
                                        ),
                                      ),
                                      Text(
                                        estimatedCost == 0
                                            ? "Not Calculated"
                                            : "PKR ${estimatedCost.toStringAsFixed(0)}",
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      if (!hasCalculated)
                                        Text(
                                          "Tap card to calculate",
                                          style: TextStyle(
                                            color: Colors.white.withOpacity(
                                              0.7,
                                            ),
                                            fontSize: 12,
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        const SizedBox(height: 150),

                        /// NEXT BUTTON
                        SizedBox(
                          width: double.infinity,
                          child: primaryButton(
                            context: context,
                            text: "Next",
                            onTap: handleNext,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
