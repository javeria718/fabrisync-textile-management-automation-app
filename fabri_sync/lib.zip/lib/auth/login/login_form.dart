import 'package:flutter/material.dart';
import 'package:fabri_sync/auth/Forgotpass/screen1.dart';
import 'package:fabri_sync/auth/signup/signup_page.dart';
import 'login_controller.dart';
import 'package:fabri_sync/widgets/custombutton.dart';
import 'package:fabri_sync/widgets/textfields.dart';

class LoginForm extends StatelessWidget {
  final String expectedRole;
  final LoginController controller;
  final VoidCallback togglePassword;
  final VoidCallback onLoginPressed;

  const LoginForm({
    super.key,
    required this.controller,
    required this.expectedRole,
    required this.togglePassword,
    required this.onLoginPressed,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isWebWide = constraints.maxWidth >= 600;

        return SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(
              horizontal: isWebWide ? 0 : 4, // frosted card already has padding
              vertical: 4,
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // ✅ Main Title centered (design fix)
                Text(
                  'FabriSync',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.w800,
                    color: Colors.white.withOpacity(0.95),
                    letterSpacing: 1,
                  ),
                ),

                const SizedBox(height: 12),

                Text(
                  'Welcome back',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                    color: Colors.white.withOpacity(0.95),
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Sign in to continue',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.white.withOpacity(0.70),
                  ),
                ),

                const SizedBox(height: 22),

                /// Email
                CustomTextFormField(
                  controller: controller.emailController,
                  label: 'Email',
                  icon: Icons.email_outlined,
                  keyboardType: TextInputType.emailAddress,
                  frostedStyle: true,
                ),

                const SizedBox(height: 14),

                /// Password
                CustomTextFormField(
                  controller: controller.passwordController,
                  label: 'Password',
                  icon: Icons.lock_outline,
                  keyboardType: TextInputType.visiblePassword,
                  obscureText: !controller.showPassword,
                  suffix: IconButton(
                    icon: Icon(
                      controller.showPassword
                          ? Icons.visibility
                          : Icons.visibility_off,
                      size: 20,
                    ),
                    onPressed: togglePassword,
                  ),
                  frostedStyle: true,
                ),

                const SizedBox(height: 6),

                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const ForgotPasswordScreen(),
                        ),
                      );
                    },
                    style: TextButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 6),
                    ),
                    child: Text(
                      'Forgot Password?',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.white.withOpacity(0.85),
                        decoration: TextDecoration.underline,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 12),

                /// Button (full width)
                SizedBox(
                  height: 46,
                  child: CustomButton(
                    width: double.infinity,
                    label: controller.isLoading ? "" : "Sign In",
                    onPressed: onLoginPressed,
                    child: controller.isLoading
                        ? const SizedBox(
                            height: 22,
                            width: 22,
                            child: CircularProgressIndicator(
                              strokeWidth: 2,
                              color: Color(
                                0xFF2563EB,
                              ), // looks good on white btn
                            ),
                          )
                        : null,
                  ),
                ),

                const SizedBox(height: 14),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Don’t have an account?",
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.white.withOpacity(0.75),
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => SignUpPage(
                              expectedRole: controller.expectedRole,
                            ),
                          ),
                        );
                      },
                      child: Text(
                        "Sign Up",
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                          color: Colors.white.withOpacity(0.92),
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
