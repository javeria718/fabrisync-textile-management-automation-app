import 'dart:ui';
import 'package:fabri_sync/utils/customcolors.dart';
import 'package:fabri_sync/view/newOrder/estimate_time.dart';
import 'package:fabri_sync/widgets/custom_appBar.dart';
import 'package:fabri_sync/widgets/primary_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class OrderInputScreen extends StatefulWidget {
  const OrderInputScreen({super.key});

  @override
  State<OrderInputScreen> createState() => _OrderInputScreenState();
}

class _OrderInputScreenState extends State<OrderInputScreen> {
  final quantityCtrl = TextEditingController();
  final materialCostCtrl = TextEditingController();

  @override
  void dispose() {
    quantityCtrl.dispose();
    materialCostCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: buildGradientAppBar("New Order"),
      body: gradientOrderBackground(
        child: Center(
          child: SingleChildScrollView(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(24),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
                  child: Container(
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.12), // 👈 white glass
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: Colors.white.withOpacity(0.25)),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black38,
                          blurRadius: 30,
                          offset: Offset(0, 20),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        _inputCard(
                          "Order Quantity",
                          Icons.inventory,
                          quantityCtrl,
                        ),
                        _inputCard(
                          "Material Cost / Unit",
                          Icons.attach_money,
                          materialCostCtrl,
                        ),

                        const SizedBox(height: 36),

                        primaryButton(
                          context: context,
                          text: "Next",
                          onTap: () {
                            if (quantityCtrl.text.isEmpty ||
                                materialCostCtrl.text.isEmpty) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                  content: Text(
                                    "Please enter all fields before proceeding",
                                  ),
                                ),
                              );
                              return;
                            }

                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => EstimateTimeScreen(
                                  quantityCtrl: quantityCtrl,
                                  materialCostCtrl: materialCostCtrl,
                                ),
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

Widget _inputCard(
  String label,
  IconData icon,
  TextEditingController controller,
) {
  return Container(
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(18),
      color: Colors.white.withOpacity(0.08), // glass look
      border: Border.all(color: Colors.white.withOpacity(0.15)),
      boxShadow: const [
        BoxShadow(color: Colors.black26, blurRadius: 20, offset: Offset(0, 10)),
      ],
    ),
    margin: const EdgeInsets.only(bottom: 16),
    padding: const EdgeInsets.all(18),
    child: TextField(
      controller: controller,
      keyboardType: TextInputType.number, // numeric keyboard
      inputFormatters: [
        FilteringTextInputFormatter.digitsOnly, // ✅ only digits allowed
      ],
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: Colors.white.withOpacity(0.7)),
        prefixIcon: Icon(icon, color: Colors.white),
        border: InputBorder.none,
      ),
    ),
  );
}
