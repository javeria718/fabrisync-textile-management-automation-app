import 'dart:ui';
import 'package:fabri_sync/utils/customcolors.dart';
import 'package:fabri_sync/view/newOrder/estimate_cost.dart';
import 'package:fabri_sync/widgets/custom_appBar.dart';
import 'package:fabri_sync/widgets/primary_button.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class EstimateTimeScreen extends StatefulWidget {
  final TextEditingController quantityCtrl;
  final TextEditingController materialCostCtrl;

  const EstimateTimeScreen({
    super.key,
    required this.quantityCtrl,
    required this.materialCostCtrl,
  });

  @override
  State<EstimateTimeScreen> createState() => _EstimateTimeScreenState();
}

class _EstimateTimeScreenState extends State<EstimateTimeScreen> {
  double estimatedTime = 0;
  bool hasCalculated = false;
  bool isCardTapped = false;
  int totalDays = 0;
  double totalProjectHours = 0;
  Map<String, double> estimatedDeptHours = {};

  Future<void> calculateTime() async {
    final qty = double.tryParse(widget.quantityCtrl.text) ?? 0;
    if (qty <= 0) return;

    final supabase = Supabase.instance.client;

    try {
      final List<Map<String, dynamic>> response = await supabase
          .from('master_time_config')
          .select();

      if (response.isEmpty) {
        throw Exception('No time config found');
      }

      Map<String, double> deptHours = {};
      double totalHours = 0;

      for (final row in response) {
        final dept = (row['department'] ?? 'UNKNOWN').toString();
        final num hoursNum = row['estimated_hours'] is num
            ? row['estimated_hours']
            : 0;
        final hoursPerUnit = hoursNum.toDouble();
        final deptTotal = qty * hoursPerUnit;

        deptHours[dept] = deptTotal;
        totalHours += deptTotal;
      }

      final duration = calculateProjectDuration(totalHours);

      if (!mounted) return; // ✅ Prevent setState after dispose

      setState(() {
        estimatedDeptHours = deptHours;
        totalProjectHours = totalHours;
        totalDays = duration['days'] as int;
        estimatedTime = totalHours;
        hasCalculated = true;
        isCardTapped = true;
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Failed to calculate estimated time')),
      );
    }
  }

  Map<String, dynamic> calculateProjectDuration(double totalHours) {
    const double workHoursPerDay = 8.0;

    final totalDays = (totalHours / workHoursPerDay).ceil();
    final remainingHours = totalHours % workHoursPerDay;

    return {
      'days': totalDays,
      'hours': totalHours,
      'remainingHours': remainingHours.round(),
    };
  }

  void handleNext() {
    if (!hasCalculated) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Please tap the card to calculate time first."),
          backgroundColor: Colors.redAccent,
        ),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => EstimateCostScreen(
          quantityCtrl: widget.quantityCtrl,
          materialCostCtrl: widget.materialCostCtrl,
          estimatedTime: estimatedTime,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: buildGradientAppBar("New Order"),
      body: gradientOrderBackground(
        child: Center(
          child: SingleChildScrollView(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(24),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 14, sigmaY: 14),
                  child: Container(
                    constraints: const BoxConstraints(minHeight: 400),
                    padding: const EdgeInsets.all(24),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(24),
                      border: Border.all(color: Colors.white.withOpacity(0.25)),
                      boxShadow: const [
                        BoxShadow(
                          color: Colors.black38,
                          blurRadius: 30,
                          offset: Offset(0, 20),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // ESTIMATE CARD
                        GestureDetector(
                          onTap: calculateTime,
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            curve: Curves.easeOut,
                            padding: const EdgeInsets.all(18),
                            height: isCardTapped ? 120 : 140,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(18),
                              gradient: const LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [Color(0x66FFFFFF), Color(0x33E0EFFF)],
                              ),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.25),
                                  blurRadius: 20,
                                  offset: const Offset(0, 10),
                                ),
                              ],
                            ),
                            child: Row(
                              children: [
                                CircleAvatar(
                                  radius: 28,
                                  backgroundColor: Colors.white.withOpacity(
                                    0.2,
                                  ),
                                  child: const Icon(
                                    Icons.analytics,
                                    color: Colors.white,
                                    size: 28,
                                  ),
                                ),
                                const SizedBox(width: 16),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      const Text(
                                        "Estimated Time",
                                        style: TextStyle(
                                          color: Colors.white70,
                                          fontSize: 14,
                                        ),
                                      ),
                                      Text(
                                        !hasCalculated
                                            ? "Not Calculated"
                                            : "$totalDays days (8hr/day)",
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontSize: 20,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                      if (hasCalculated)
                                        Text(
                                          "Total: ${totalProjectHours.toStringAsFixed(0)} hrs",
                                          style: TextStyle(
                                            color: Colors.white.withOpacity(
                                              0.75,
                                            ),
                                            fontSize: 12,
                                          ),
                                        ),
                                      if (!hasCalculated)
                                        Text(
                                          "Tap card to calculate",
                                          style: TextStyle(
                                            color: Colors.white.withOpacity(
                                              0.7,
                                            ),
                                            fontSize: 12,
                                          ),
                                        ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),

                        // DEPARTMENT-WISE ESTIMATE
                        if (hasCalculated)
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: 20),
                              const Text(
                                "Department-wise Estimated Time",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 16,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              const SizedBox(height: 12),
                              ...estimatedDeptHours.entries.map((e) {
                                return Padding(
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 6,
                                  ),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        e.key,
                                        style: const TextStyle(
                                          color: Colors.white70,
                                        ),
                                      ),
                                      Text(
                                        "${(e.value / 8).ceil()} days (${e.value.round()} hrs)",
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              }).toList(),
                            ],
                          ),

                        const SizedBox(height: 150),

                        // NEXT BUTTON
                        SizedBox(
                          width: double.infinity,
                          child: primaryButton(
                            context: context,
                            text: "Next",
                            onTap: handleNext,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
